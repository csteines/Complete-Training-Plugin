<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Tickets_Plus__Commerce__WPEC__Main' );


	class TribeWPECTickets extends Tribe__Tickets_Plus__Commerce__WPEC__Main {

	}
