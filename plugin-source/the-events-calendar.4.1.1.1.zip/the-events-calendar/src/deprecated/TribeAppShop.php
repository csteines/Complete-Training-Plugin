<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__App_Shop' );


	class TribeAppShop extends Tribe__Events__App_Shop {

	}