<?php


	abstract class Tribe__Events__Asset__Abstract_Events_Css {

		abstract public function handle( array &$stylesheets, $mobile_break );

	}