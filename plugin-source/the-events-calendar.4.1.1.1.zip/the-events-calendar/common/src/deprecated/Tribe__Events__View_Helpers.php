<?php
_deprecated_file( __FILE__, '4.0', 'Tribe__View_Helpers.php' );

class Tribe__Events__View_Helpers extends Tribe__View_Helpers {}
