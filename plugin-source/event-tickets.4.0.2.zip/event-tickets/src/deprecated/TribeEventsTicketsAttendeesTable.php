<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Tickets__Attendees_Table' );


	class TribeEventsTicketsAttendeesTable extends Tribe__Tickets__Attendees_Table {

	}