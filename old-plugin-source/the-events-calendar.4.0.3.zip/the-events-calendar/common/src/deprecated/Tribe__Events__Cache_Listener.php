<?php
_deprecated_file( __FILE__, '4.0', 'Tribe__Cache_Listener.php' );

class Tribe__Events__Cache_Listener extends Tribe__Cache_Listener {}
