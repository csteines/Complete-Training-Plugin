<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Tickets_Plus__Commerce__WPEC__Email' );


	class WPSC_Purchase_Log_Tickets extends Tribe__Tickets_Plus__Commerce__WPEC__Email {

	}
