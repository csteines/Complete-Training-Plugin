<?php include dirname( __FILE__ ) . '/price-fields.php'; ?>
<tr class="<?php $this->tr_class(); ?>">
	<td><label for="ticket_shopp_stock"><?php esc_html_e( 'Stock:', 'event-tickets-plus' ); ?></label></td>
	<td>
		<input type='text' id='ticket_shopp_stock' name='ticket_shopp_stock' class="ticket_field" size='7'
		       value='<?php echo esc_attr( $stock ); ?>'/>
		<p class="description"><?php esc_html_e( 'Total available # of this ticket type: leave blank if you do not require stock control', 'event-tickets-plus' ); ?></p>
	</td>
</tr>

<tr class="<?php $this->tr_class(); ?>">
	<td><label for="ticket_shopp_sku"><?php esc_html_e( 'SKU:', 'event-tickets-plus' ); ?></label></td>
	<td>
		<input type="text" id="ticket_shopp_sku" name="ticket_shopp_sku" class="ticket_field" size="7"
		       value="<?php echo esc_attr( $sku ); ?>"/>
		<p class="description"><?php esc_html_e( "A unique identifying code for each ticket type you're selling", 'event-tickets-plus' ); ?></p>
	</td>

</tr>
<?php
if ( class_exists( 'Tribe__Events__Pro__Main' ) ) {
	?>
	<tr class="<?php $this->tr_class(); ?>">
		<td colspan="2" class="tribe_sectionheader updated">
			<p>
				<?php esc_html_e( 'Selling tickets for recurring events', 'event-tickets-plus' ); ?> <span id="selling-tickets-info" class="target dashicons dashicons-editor-help bumpdown-trigger"></span>
			</p>
			<div class="bumpdown" data-trigger="selling-tickets-info">
				<?php esc_html_e( 'Currently, ShoppTickets will only show up on the frontend once per full event. For PRO users this means the same ticket will appear across all events in the series. Please configure your events accordingly.', 'event-tickets-plus' ); ?>
			</div>
		</td>
	</tr>
	<?php
}
